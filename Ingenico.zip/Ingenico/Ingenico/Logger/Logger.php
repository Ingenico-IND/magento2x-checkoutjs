<?php

namespace Ingenico\Ingenico\Logger;

class Logger extends \Monolog\Logger
{
}
