var config = {
    paths: {
        'ingenico': 'https://www.paynimo.com/Paynimocheckout/server/lib/checkout'
    },
    shim: {
        'ingenico': {
            deps: ['jquery']
        }
    }
};