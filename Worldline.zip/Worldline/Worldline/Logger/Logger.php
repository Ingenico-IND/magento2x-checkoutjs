<?php

namespace Worldline\Worldline\Logger;

class Logger extends \Monolog\Logger
{
}
