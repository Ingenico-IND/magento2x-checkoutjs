var config = {
    paths: {
        'Worldline': 'https://www.paynimo.com/Paynimocheckout/server/lib/checkout'
    },
    shim: {
        'Worldline': {
            deps: ['jquery']
        }
    }
};